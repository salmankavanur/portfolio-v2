"use client";

import { useState } from "react";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { motion } from "framer-motion";

const allCategories = ["All", "Web Design", "Graphic Design", "Print Design", "Flyer Design"];

interface PortfolioItem {
  image: string;
  title: string;
  category: string;
  href: string;
}

const portfolioItems: PortfolioItem[] = [
  {
    image: "https://ext.same-assets.com/1656152839/4013486423.jpeg",
    title: "Brochure Design",
    category: "Print Design",
    href: "https://www.behance.net/gallery/175280677/Brochure-Design-Landscape-Print"
  },
  {
    image: "https://ext.same-assets.com/542509979/1327173141.jpeg",
    title: "Responsive Website Design",
    category: "Web Design",
    href: "https://www.behance.net/gallery/197521677/Web-Design-Elementor-Wordpress"
  },
  {
    image: "https://ext.same-assets.com/3449514301/227553070.jpeg",
    title: "Arabic Book Design",
    category: "Print Design",
    href: "https://www.behance.net/gallery/200146981/Arabic-Book-Cover-Design"
  },
  {
    image: "https://ext.same-assets.com/3159438604/4177502529.jpeg",
    title: "3 Fold Brochure Design",
    category: "Print Design",
    href: "https://www.behance.net/gallery/197516607/Brochure-Design-Print-Design-"
  },
  {
    image: "https://ext.same-assets.com/1498376394/2515084413.jpeg",
    title: "Election Campaign Design",
    category: "Flyer Design",
    href: "https://www.behance.net/gallery/172282465/Election-Campaign-(-Social-Media-PosterFlyerCard)"
  },
  {
    image: "https://ext.same-assets.com/2788829444/2448085752.jpeg",
    title: "Educational Website Design",
    category: "Web Design",
    href: "https://www.behance.net/gallery/197546171/Educational-Website-Elementor-Wordpress-CMS"
  },
];

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.3
    }
  }
};

const filterVariants = {
  hidden: { opacity: 0, y: -20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 }
  }
};

export function PortfolioSection() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredItems = activeCategory === "All"
    ? portfolioItems
    : portfolioItems.filter(item => item.category === activeCategory);

  return (
    <section className="py-20">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-4">Portfolio</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Selected Work - Showcasing a variety of projects across web design, graphic design, and print design.
          </p>

          <motion.div
            className="flex flex-wrap justify-center gap-2 mt-8"
            variants={filterVariants}
            initial="hidden"
            animate="visible"
          >
            {allCategories.map((category) => (
              <Badge
                key={category}
                variant={activeCategory === category ? "default" : "outline"}
                className="cursor-pointer text-sm px-4 py-2 transition-all duration-300"
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </motion.div>
        </motion.div>

        <motion.div
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
        >
          {filteredItems.map((item, index) => (
            <PortfolioItem key={index} item={item} index={index} />
          ))}
        </motion.div>

        <motion.div
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <Button asChild size="lg">
            <Link href="/portfolio">View All Projects</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}

function PortfolioItem({ item, index }: { item: PortfolioItem; index: number }) {
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        delay: index * 0.1
      }
    }
  };

  return (
    <motion.div
      variants={itemVariants}
      className="group overflow-hidden rounded-lg border"
      whileHover={{
        y: -5,
        transition: { duration: 0.2 }
      }}
    >
      <Link href={item.href} target="_blank" rel="noopener noreferrer">
        <div className="relative">
          <AspectRatio ratio={16 / 9}>
            <img
              src={item.image}
              alt={item.title}
              className="object-cover transition-transform duration-500 group-hover:scale-110"
            />
          </AspectRatio>
          <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
            <Badge variant="secondary" className="self-start mb-2">
              {item.category}
            </Badge>
            <h3 className="text-white font-medium text-lg">{item.title}</h3>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
