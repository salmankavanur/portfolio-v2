"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";
import { motion } from "framer-motion";

const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const imageReveal = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.6, ease: "easeOut" }
  }
};

const statsVariant = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      delay: 0.2
    }
  }
};

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20 md:py-24 lg:py-32">
      <div className="container relative z-10">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="space-y-6"
          >
            <motion.div variants={fadeInUp} className="space-y-2">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Hi, I&apos;m Salman
                <motion.span
                  className="block"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  A Web &amp; Graphic
                  <motion.span
                    className="block"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                  >
                    Designer
                  </motion.span>
                </motion.span>
              </h1>
              <motion.p variants={fadeInUp} className="text-lg text-muted-foreground max-w-lg">
                A Freelance Web & Graphic Designer based in Kerala, India. I strive to build immersive and beautiful websites through carefully crafted user-centric design.
              </motion.p>
            </motion.div>
            <motion.div variants={fadeInUp} className="flex flex-wrap gap-4">
              <Button asChild size="lg">
                <Link href="/portfolio">View My Works</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/contact">Contact Me</Link>
              </Button>
            </motion.div>
            <motion.div variants={fadeInUp} className="flex items-center space-x-4 pt-4">
              <p className="text-sm font-medium">Follow Me:</p>
              <div className="flex space-x-3">
                <Link
                  href="https://www.linkedin.com/in/salmanmp/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  LinkedIn
                </Link>
                <Link
                  href="https://www.instagram.com/salman_kavanur/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Instagram
                </Link>
                <Link
                  href="https://www.behance.net/salmanmp"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Behance
                </Link>
                <Link
                  href="https://github.com/salmankavanur/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  GitHub
                </Link>
              </div>
            </motion.div>
          </motion.div>
          <motion.div
            className="relative"
            initial="hidden"
            animate="visible"
            variants={imageReveal}
          >
            <div className="aspect-[4/3] overflow-hidden rounded-lg">
              <img
                src="https://ext.same-assets.com/1352563405/518262652.webp"
                alt="Salman MP - Freelance Web Designer in Malappuram"
                className="object-cover w-full h-full"
              />
            </div>
            <motion.div
              className="absolute -bottom-6 -left-6 bg-muted p-4 rounded-lg"
              variants={statsVariant}
            >
              <div className="space-y-1">
                <p className="text-sm font-medium">Experience</p>
                <p className="text-2xl font-bold">7+ Years</p>
              </div>
            </motion.div>
            <motion.div
              className="absolute -top-6 -right-6 bg-muted p-4 rounded-lg"
              variants={statsVariant}
            >
              <div className="space-y-1">
                <p className="text-sm font-medium">Projects</p>
                <p className="text-2xl font-bold">300+</p>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
      <motion.div
        className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-primary/5 blur-3xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
      ></motion.div>
      <motion.div
        className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-primary/5 blur-3xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5, delay: 0.2 }}
      ></motion.div>
    </section>
  );
}
