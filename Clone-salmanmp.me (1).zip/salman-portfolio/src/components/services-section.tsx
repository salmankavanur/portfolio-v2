"use client";

import {
  Globe,
  Paintbrush,
  TrendingUp,
  Server,
  Library,
  Video
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { motion } from "framer-motion";

const services = [
  {
    icon: <Globe className="h-10 w-10" />,
    title: "Web Design",
    description: "Expert in creating responsive and user-centric designs with proficiency in various web design tools and technologies.",
    skills: ["HTML | CSS | JavaScript", "WordPress | Elementor | WPBakery", "PHP | Laravel", "Bootstrap / SASS"],
    href: "/services/web-design"
  },
  {
    icon: <TrendingUp className="h-10 w-10" />,
    title: "Digital Marketing",
    description: "As a leading Digital Marketing Strategist in Malappuram, Kerala, I offer a comprehensive suite of services tailored to meet the unique needs of your business.",
    skills: ["Search Engine Optimization", "Social Media Marketing", "Content Marketing", "Data Analytics"],
    href: "/services/digital-marketing"
  },
  {
    icon: <Video className="h-10 w-10" />,
    title: "Media Passion",
    description: "In the captivating world of media, I'm not just a designer — I'm a visual treater. From drone photo/videography to seamless editing and color grading, I bring visuals to life.",
    skills: ["Adobe Premiere Pro", "After Effects", "Drone Photo/Videography", "Photography + Videography", "Editing and Color Grading", "Live Streaming and Broadcasting"],
    href: "/services/media"
  },
  {
    icon: <Paintbrush className="h-10 w-10" />,
    title: "Graphic Design",
    description: "Specializing in creating visually compelling designs for various media, ensuring brand consistency and engagement.",
    skills: ["Social Media Design", "Flyer Design", "Brochure", "Print Design", "Adobe Creative Suite - Photoshop/Illustrator/InDesign"],
    href: "/services/graphic-design"
  },
  {
    icon: <Server className="h-10 w-10" />,
    title: "Hosting & Server Management",
    description: "Well-experienced in hosting and server management to ensure smooth and reliable web operations.",
    skills: ["Hosting", "Server Management", "Dedicated Servers"],
    href: "/services/hosting"
  },
  {
    icon: <Library className="h-10 w-10" />,
    title: "Library & Digitalization",
    description: "Proficient in library digitalization using Koha, ensuring efficient management and accessibility of digital resources.",
    skills: ["Library Digitalization", "Koha", "Digital Resource Management"],
    href: "/services/library-digitalization"
  }
];

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  }
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      type: "spring",
      stiffness: 100
    }
  }
};

export function ServicesSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeIn}
        >
          <h2 className="text-3xl font-bold mb-4">Services</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            My Expertise Areas - Providing top-quality services in web design, graphic design, digital marketing, and more.
          </p>
        </motion.div>

        <motion.div
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              variants={cardVariants}
              whileHover={{
                y: -8,
                transition: { duration: 0.2 }
              }}
            >
              <Link href={service.href} className="group block h-full">
                <Card className="h-full transition-all duration-300 hover:shadow-lg border-2 border-transparent hover:border-primary/10">
                  <CardHeader>
                    <motion.div
                      className="mb-4 text-primary group-hover:text-accent transition-colors duration-300"
                      initial={{ scale: 1 }}
                      whileHover={{
                        scale: 1.1,
                        rotate: 5,
                        transition: { duration: 0.3 }
                      }}
                    >
                      {service.icon}
                    </motion.div>
                    <CardTitle className="text-xl group-hover:text-primary transition-colors">
                      {service.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <CardDescription className="text-base">
                      {service.description}
                    </CardDescription>
                    <ul className="space-y-1 text-sm">
                      {service.skills.map((skill, i) => (
                        <li key={i} className="text-muted-foreground">
                          • {skill}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
