"use client";

import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { motion } from "framer-motion";

interface Testimonial {
  text: string;
  name: string;
  role: string;
  location: string;
  avatar: string;
}

const testimonials: Testimonial[] = [
  {
    text: "Salman is a multi-talented professional with an excellent personality. His expertise has significantly contributed to the growth of our business, particularly in web design, Google Workspace management, and social media profile enhancement. Thanks to his efforts and timely updates, we have achieved a leading position in the sector.",
    name: "Mohamed Nazeemudeen",
    role: "Project Manager, RKD Works LLC",
    location: "Dubai, UAE",
    avatar: "https://ext.same-assets.com/2089583212/2746487974.png",
  },
  {
    text: "Salman was fantastic—responsive, professional, knowledgeable, and skilled. He quickly grasped our intended concept and helped us achieve a clean and beautiful presentation. His talent and skills were evident throughout his work with our company, significantly contributing to our business growth. He did an excellent job as a digital marketer and designer.",
    name: "Moosa Abdul Basith",
    role: "CEO, Mabco Developers",
    location: "Perinthalmanna, Kerala, India",
    avatar: "https://ext.same-assets.com/2297260833/1703067666.png",
  },
  {
    text: "Salman is a multi-talented personality and a wonderful individual. His extraordinary skills and talent have significantly contributed to our brand's growth, enabling us to reach a wider audience and secure major projects. Salman excels in web designing, graphic designing, aerial shooting, and more, proving himself to be an invaluable asset to our team.",
    name: "Sayyid Noufal Shihab",
    role: "Managing Director, Alif Media Solutions",
    location: "Perinthalmanna, Kerala, India",
    avatar: "https://ext.same-assets.com/1621712162/3598258398.png",
  },
];

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  }
};

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <motion.div
          className="text-center mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          variants={fadeIn}
        >
          <h2 className="text-3xl font-bold mb-4">Testimonials</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Building Success Together - What clients say about my work and collaboration.
          </p>
        </motion.div>

        <motion.div
          className="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
        >
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} index={index} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

function TestimonialCard({ testimonial, index }: { testimonial: Testimonial; index: number }) {
  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        type: "spring",
        stiffness: 100,
        delay: index * 0.1
      }
    }
  };

  return (
    <motion.div
      variants={cardVariants}
      whileHover={{
        y: -5,
        transition: { duration: 0.2 }
      }}
    >
      <Card className="h-full flex flex-col">
        <CardHeader className="pb-2">
          <motion.div
            className="text-primary"
            initial={{ scale: 1, opacity: 0.2 }}
            whileInView={{
              scale: 1.1,
              opacity: 1,
              transition: {
                duration: 0.5,
                delay: 0.2 + (index * 0.1)
              }
            }}
            viewport={{ once: true }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="w-12 h-12 opacity-20"
            >
              <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
            </svg>
          </motion.div>
        </CardHeader>
        <CardContent className="flex-grow">
          <motion.p
            className="text-muted-foreground"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{
              opacity: 1,
              y: 0,
              transition: {
                duration: 0.5,
                delay: 0.3 + (index * 0.1)
              }
            }}
            viewport={{ once: true }}
          >
            {testimonial.text}
          </motion.p>
        </CardContent>
        <CardFooter className="pt-4 border-t">
          <motion.div
            className="flex items-center space-x-3"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{
              opacity: 1,
              x: 0,
              transition: {
                duration: 0.5,
                delay: 0.4 + (index * 0.1)
              }
            }}
            viewport={{ once: true }}
          >
            <Avatar>
              <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
              <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sm">{testimonial.name}</p>
              <p className="text-xs text-muted-foreground">{testimonial.role}</p>
              <p className="text-xs text-muted-foreground">{testimonial.location}</p>
            </div>
          </motion.div>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
