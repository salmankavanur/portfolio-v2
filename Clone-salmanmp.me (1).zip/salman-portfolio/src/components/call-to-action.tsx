"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export function CallToAction() {
  return (
    <section className="py-20 relative overflow-hidden">
      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          viewport={{ once: true, amount: 0.3 }}
        >
          <Card className="border-none bg-muted/50 backdrop-blur-sm shadow-lg">
            <CardHeader className="text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <CardTitle className="text-3xl font-bold">Have an idea? Let's build it!</CardTitle>
                <CardDescription className="text-lg max-w-2xl mx-auto pt-2">
                  Ready to transform your digital presence? Let's collaborate to create something amazing together.
                </CardDescription>
              </motion.div>
            </CardHeader>
            <CardContent>
              <motion.div
                className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-xl mx-auto"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="w-full sm:w-auto"
                >
                  <Button asChild size="lg" className="w-full">
                    <Link href="/contact">
                      Contact Me
                      <motion.span
                        initial={{ x: 0 }}
                        animate={{ x: [0, 5, 0] }}
                        transition={{
                          repeat: Infinity,
                          repeatType: "loop",
                          duration: 1.5,
                          ease: "easeInOut"
                        }}
                      >
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </motion.span>
                    </Link>
                  </Button>
                </motion.div>

                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="w-full sm:w-auto"
                >
                  <Button asChild variant="outline" size="lg" className="w-full">
                    <Link href="mailto:hello@salmanmp.me">
                      hello@salmanmp.me
                    </Link>
                  </Button>
                </motion.div>
              </motion.div>
              <motion.div
                className="text-center mt-8"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.6 }}
                viewport={{ once: true }}
              >
                <p className="text-muted-foreground text-sm">
                  Or follow me on:
                </p>
                <div className="flex justify-center gap-4 mt-2">
                  <SocialLink href="https://www.linkedin.com/in/salmanmp/">LinkedIn</SocialLink>
                  <SocialLink href="https://www.instagram.com/salman_kavanur/">Instagram</SocialLink>
                  <SocialLink href="https://www.behance.net/salmanmp">Behance</SocialLink>
                  <SocialLink href="https://github.com/salmankavanur/">GitHub</SocialLink>
                </div>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      <motion.div
        className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-primary/5 blur-3xl"
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1 }}
        viewport={{ once: true }}
      ></motion.div>
      <motion.div
        className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-primary/5 blur-3xl"
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1, delay: 0.3 }}
        viewport={{ once: true }}
      ></motion.div>
    </section>
  );
}

function SocialLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <motion.span
      whileHover={{ scale: 1.1, y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <Link
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className="text-muted-foreground hover:text-foreground transition-colors"
      >
        {children}
      </Link>
    </motion.span>
  );
}
