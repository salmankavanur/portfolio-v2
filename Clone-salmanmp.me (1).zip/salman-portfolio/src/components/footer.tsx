import { buttonVariants } from "@/components/ui/button";
import Link from "next/link";
import {
  Linkedin,
  Github,
  Instagram,
  Twitter,
  Mail,
  Phone,
  MapPin,
  Settings
} from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t py-12 md:py-16">
      <div className="container grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-4">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold">Salman MP</Link>
          </div>
          <p className="text-muted-foreground text-sm max-w-xs">
            Web & Graphic Designer based in Kerala, India. Offering services in design, digital marketing, and media production.
          </p>

          <div className="flex items-center space-x-4">
            <Link
              href="https://www.linkedin.com/in/salmanmp/"
              className={buttonVariants({ variant: "ghost", size: "icon" })}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              <Linkedin className="h-4 w-4" />
            </Link>
            <Link
              href="https://github.com/salmankavanur/"
              className={buttonVariants({ variant: "ghost", size: "icon" })}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
            >
              <Github className="h-4 w-4" />
            </Link>
            <Link
              href="https://www.instagram.com/salman_kavanur/"
              className={buttonVariants({ variant: "ghost", size: "icon" })}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
            >
              <Instagram className="h-4 w-4" />
            </Link>
            <Link
              href="https://twitter.com/salman_kavanur"
              className={buttonVariants({ variant: "ghost", size: "icon" })}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
            >
              <Twitter className="h-4 w-4" />
            </Link>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold">Services</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              <Link href="/services/web-design" className="hover:text-foreground transition-colors">
                Web Design & Development
              </Link>
            </li>
            <li>
              <Link href="/services/digital-marketing" className="hover:text-foreground transition-colors">
                Digital Marketing
              </Link>
            </li>
            <li>
              <Link href="/services/graphic-design" className="hover:text-foreground transition-colors">
                Graphic Design
              </Link>
            </li>
            <li>
              <Link href="/services/media" className="hover:text-foreground transition-colors">
                Media Production
              </Link>
            </li>
            <li>
              <Link href="/services/hosting" className="hover:text-foreground transition-colors">
                Hosting & Server Management
              </Link>
            </li>
            <li>
              <Link href="/services/library-digitalization" className="hover:text-foreground transition-colors">
                Library & Digitalization
              </Link>
            </li>
          </ul>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold">Quick Links</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              <Link href="/" className="hover:text-foreground transition-colors">Home</Link>
            </li>
            <li>
              <Link href="/about" className="hover:text-foreground transition-colors">About</Link>
            </li>
            <li>
              <Link href="/portfolio" className="hover:text-foreground transition-colors">Portfolio</Link>
            </li>
            <li>
              <Link href="/services" className="hover:text-foreground transition-colors">Services</Link>
            </li>
            <li>
              <Link href="/blog" className="hover:text-foreground transition-colors">Blog</Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-foreground transition-colors">Contact</Link>
            </li>
          </ul>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold">Contact Info</h3>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start">
              <MapPin className="mr-2 h-4 w-4 mt-0.5 text-primary shrink-0" />
              <span>Kerala, India</span>
            </li>
            <li>
              <Link href="mailto:hello@salmanmp.me" className="flex items-center hover:text-foreground transition-colors">
                <Mail className="mr-2 h-4 w-4 text-primary" />
                <span>hello@salmanmp.me</span>
              </Link>
            </li>
            <li>
              <Link href="tel:+918129489071" className="flex items-center hover:text-foreground transition-colors">
                <Phone className="mr-2 h-4 w-4 text-primary" />
                <span>+91 8129489071</span>
              </Link>
            </li>
            <li className="mt-6">
              <Link
                href="/admin/login"
                className="flex items-center text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                <Settings className="mr-1 h-3 w-3" />
                <span>Admin</span>
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div className="container mt-12 border-t pt-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground order-2 md:order-1">
            &copy; {currentYear} Salman MP. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground order-1 md:order-2">
            <Link href="/privacy-policy" className="hover:text-foreground transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-foreground transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
