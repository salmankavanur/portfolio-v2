import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import {
  Globe,
  Paintbrush,
  TrendingUp,
  Server,
  Library,
  Video,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

const services = [
  {
    icon: <Globe className="h-16 w-16" />,
    title: "Web Design",
    description: "Expert in creating responsive and user-centric designs with proficiency in various web design tools and technologies.",
    skills: ["HTML | CSS | JavaScript", "WordPress | Elementor | WPBakery", "PHP | Laravel", "Bootstrap / SASS"],
    href: "/services/web-design",
    longDescription: "As a web designer, I focus on creating websites that not only look great but also provide an exceptional user experience. I take a thoughtful approach to design, considering both aesthetics and functionality to create websites that effectively communicate your message and achieve your goals. From responsive layouts to interactive elements, I ensure that every aspect of your website is optimized for performance and usability across all devices.",
  },
  {
    icon: <TrendingUp className="h-16 w-16" />,
    title: "Digital Marketing",
    description: "As a leading Digital Marketing Strategist in Malappuram, Kerala, I offer a comprehensive suite of services tailored to meet the unique needs of your business.",
    skills: ["Search Engine Optimization", "Social Media Marketing", "Content Marketing", "Data Analytics"],
    href: "/services/digital-marketing",
    longDescription: "Digital marketing is essential for businesses looking to establish a strong online presence. I provide comprehensive digital marketing services that help you reach your target audience and achieve your business objectives. From search engine optimization (SEO) to social media marketing, I develop strategies that increase your visibility, drive traffic to your website, and convert visitors into customers. My data-driven approach ensures that your marketing efforts deliver measurable results.",
  },
  {
    icon: <Video className="h-16 w-16" />,
    title: "Media Production",
    description: "In the captivating world of media, I'm not just a designer — I'm a visual treater. From drone photo/videography to seamless editing and color grading, I bring visuals to life.",
    skills: ["Adobe Premiere Pro", "After Effects", "Drone Photo/Videography", "Photography + Videography", "Editing and Color Grading", "Live Streaming and Broadcasting"],
    href: "/services/media",
    longDescription: "Media production is an art form that combines creativity and technical expertise. I specialize in creating high-quality media content that captivates your audience and effectively conveys your message. From professional photography and videography to drone aerial shots, I provide a full range of media services. My expertise in editing and color grading ensures that your final product has a polished, professional look that stands out. I also offer live streaming and broadcasting services for events and special occasions.",
  },
  {
    icon: <Paintbrush className="h-16 w-16" />,
    title: "Graphic Design",
    description: "Specializing in creating visually compelling designs for various media, ensuring brand consistency and engagement.",
    skills: ["Social Media Design", "Flyer Design", "Brochure Design", "Print Design", "Adobe Creative Suite - Photoshop/Illustrator/InDesign"],
    href: "/services/graphic-design",
    longDescription: "Graphic design is the art of visual communication. I create designs that not only look good but also effectively communicate your message to your target audience. My graphic design services include everything from logo design and brand identity to marketing materials and social media graphics. I work closely with clients to understand their vision and create designs that reflect their brand personality and resonate with their audience. My expertise in Adobe Creative Suite allows me to produce high-quality designs for both print and digital media.",
  },
  {
    icon: <Server className="h-16 w-16" />,
    title: "Hosting & Server Management",
    description: "Well-experienced in hosting and server management to ensure smooth and reliable web operations.",
    skills: ["Hosting", "Server Management", "Dedicated Servers"],
    href: "/services/hosting",
    longDescription: "Reliable hosting and efficient server management are crucial for the performance and security of your website. I provide hosting solutions tailored to your specific needs, whether you require shared hosting, VPS, or dedicated servers. My server management services ensure that your website remains secure, fast, and always available to your visitors. I handle everything from server setup and configuration to ongoing maintenance and troubleshooting, allowing you to focus on your business while I take care of the technical aspects.",
  },
  {
    icon: <Library className="h-16 w-16" />,
    title: "Library & Digitalization",
    description: "Proficient in library digitalization using Koha, ensuring efficient management and accessibility of digital resources.",
    skills: ["Library Digitalization", "Koha", "Digital Resource Management"],
    href: "/services/library-digitalization",
    longDescription: "In today's digital age, libraries need to adapt to meet the changing needs of their users. I specialize in library digitalization, helping libraries transition from traditional to digital systems. My expertise in Koha library management system allows me to create efficient, user-friendly digital libraries that enhance accessibility and streamline resource management. I provide comprehensive solutions for cataloging, circulation, and access to digital resources, enabling libraries to better serve their communities while preserving valuable information for future generations.",
  }
];

export default function ServicesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Header */}
        <section className="py-20 bg-muted/30">
          <div className="container">
            <h1 className="text-4xl font-bold mb-4">Services</h1>
            <p className="text-muted-foreground max-w-3xl">
              Comprehensive web design, graphic design, digital marketing, and media production services
              tailored to meet the unique needs of your business.
            </p>
          </div>
        </section>

        {/* Services Overview */}
        <section className="py-16">
          <div className="container">
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {services.map((service, index) => (
                <Card key={index} className="h-full flex flex-col">
                  <CardHeader>
                    <div className="text-primary mb-4">
                      {service.icon}
                    </div>
                    <CardTitle className="text-2xl">{service.title}</CardTitle>
                    <CardDescription className="text-base">
                      {service.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2 flex-grow">
                    <h4 className="font-medium">Skills & Tools:</h4>
                    <ul className="space-y-1">
                      {service.skills.map((skill, i) => (
                        <li key={i} className="text-muted-foreground text-sm">
                          • {skill}
                        </li>
                      ))}
                    </ul>
                    <p className="pt-4 text-sm text-muted-foreground">
                      {service.longDescription.substring(0, 150)}...
                    </p>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={service.href}>
                        Learn More
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Work Process */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">My Work Process</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                A systematic approach to ensure high-quality results for every project.
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              <div className="relative">
                <div className="bg-primary text-primary-foreground rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4">
                  1
                </div>
                <h3 className="text-xl font-medium mb-2">Research & Discovery</h3>
                <p className="text-muted-foreground">
                  Understanding your needs, goals, and target audience to lay a strong foundation for the project.
                </p>
              </div>

              <div className="relative">
                <div className="bg-primary text-primary-foreground rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4">
                  2
                </div>
                <h3 className="text-xl font-medium mb-2">Planning & Strategy</h3>
                <p className="text-muted-foreground">
                  Developing a comprehensive plan and strategy tailored to your specific requirements and objectives.
                </p>
              </div>

              <div className="relative">
                <div className="bg-primary text-primary-foreground rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4">
                  3
                </div>
                <h3 className="text-xl font-medium mb-2">Design & Development</h3>
                <p className="text-muted-foreground">
                  Creating visually appealing and functional designs that effectively communicate your message.
                </p>
              </div>

              <div className="relative">
                <div className="bg-primary text-primary-foreground rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold mb-4">
                  4
                </div>
                <h3 className="text-xl font-medium mb-2">Review & Launch</h3>
                <p className="text-muted-foreground">
                  Thorough testing and refinement to ensure the final product meets all requirements before launch.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16">
          <div className="container">
            <Card className="border-none bg-muted/50 backdrop-blur-sm shadow-lg">
              <CardHeader className="text-center">
                <CardTitle className="text-3xl font-bold">Ready to start your project?</CardTitle>
                <CardDescription className="text-lg max-w-2xl mx-auto pt-2">
                  Let's collaborate to create something amazing together. Get in touch to discuss your project needs.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-wrap justify-center gap-4">
                <Button asChild size="lg">
                  <Link href="/contact">
                    Contact Me
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" asChild size="lg">
                  <Link href="/portfolio">View My Work</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
