import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Header */}
        <section className="py-20 bg-muted/30">
          <div className="container">
            <h1 className="text-4xl font-bold mb-4">About Me</h1>
            <p className="text-muted-foreground max-w-3xl">
              Web & Graphic Designer Based in Kerala, India
            </p>
          </div>
        </section>

        {/* Profile Section */}
        <section className="py-16">
          <div className="container">
            <div className="grid gap-12 md:grid-cols-2 items-center">
              <div>
                <img
                  src="https://ext.same-assets.com/1352563405/518262652.webp"
                  alt="Salman MP - Freelance Web Designer in Malappuram"
                  className="rounded-lg w-full"
                />
              </div>
              <div className="space-y-6">
                <h2 className="text-3xl font-bold">Salman MP</h2>
                <h3 className="text-xl text-muted-foreground">Web & Graphic Designer</h3>
                <p className="text-base">
                  Experienced and passionate Web and Graphic Designer with over 7 years of expertise in both fields.
                  My strong portfolio features a variety of design projects, including brochures, flyers, posters,
                  and social media designs. Proficient in Adobe Suite (Photoshop, Illustrator, Premiere, After Effects,
                  and InDesign) and Canva, I excel at creating visually stunning and effective marketing materials,
                  as well as modern, user-friendly websites.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="font-medium">Name:</p>
                    <p className="text-muted-foreground">Salman MP</p>
                  </div>
                  <div>
                    <p className="font-medium">Nationality:</p>
                    <p className="text-muted-foreground">Indian</p>
                  </div>
                  <div>
                    <p className="font-medium">Phone:</p>
                    <p className="text-muted-foreground">+91 8129489071</p>
                  </div>
                  <div>
                    <p className="font-medium">Email:</p>
                    <p className="text-muted-foreground">hello@salmanmp.me</p>
                  </div>
                  <div>
                    <p className="font-medium">Experience:</p>
                    <p className="text-muted-foreground">7+ years</p>
                  </div>
                  <div>
                    <p className="font-medium">Freelance:</p>
                    <p className="text-muted-foreground">Available</p>
                  </div>
                  <div>
                    <p className="font-medium">Language:</p>
                    <p className="text-muted-foreground">Malayalam, English, Arabic</p>
                  </div>
                </div>
                <div className="pt-4">
                  <Button asChild size="lg">
                    <Link href="/assets/downloads/salman-cv.pdf" target="_blank">
                      Download CV
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Resume Tabs Section */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <h2 className="text-3xl font-bold mb-8 text-center">My Resume</h2>

            <Tabs defaultValue="experience" className="max-w-4xl mx-auto">
              <TabsList className="grid w-full grid-cols-3 md:grid-cols-5">
                <TabsTrigger value="about">About Me</TabsTrigger>
                <TabsTrigger value="experience">Experience</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
                <TabsTrigger value="skills">Skills</TabsTrigger>
                <TabsTrigger value="awards">Awards</TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="mt-6 space-y-4">
                <h3 className="text-xl font-semibold">Web & Graphic Designer</h3>
                <p>
                  Experienced and passionate Web and Graphic Designer with over 7 years of expertise in both fields.
                  My strong portfolio features a variety of design projects, including brochures, flyers, posters,
                  and social media designs. Proficient in Adobe Suite (Photoshop, Illustrator, Premiere, After Effects,
                  and InDesign) and Canva, I excel at creating visually stunning and effective marketing materials,
                  as well as modern, user-friendly websites.
                </p>
              </TabsContent>

              <TabsContent value="experience" className="mt-6 space-y-8">
                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2021 - Present</div>
                  <h3 className="text-lg font-semibold">Media Coordinator | Senior Web & Graphic Designer</h3>
                  <p className="text-muted-foreground">AIC - Educational & Cultural Centre</p>
                  <p>
                    Currently I'm working as the Media coordinator at the most well-known educational & cultural centre based in Kerala, India.
                    Here I have to deal with Graphic Design, Web Design, Photography, Videography, Live Telecasting and all other technical supports.
                  </p>
                </div>

                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2020 - 2021</div>
                  <h3 className="text-lg font-semibold">Graphic Designer & Digital Marketer</h3>
                  <p className="text-muted-foreground">Mabco Developers</p>
                  <p>
                    As a Graphic Designer and Digital Marketer, I performed my level best at the Leading builders in Kerala, India.
                  </p>
                </div>

                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2015 - 2020</div>
                  <h3 className="text-lg font-semibold">Senior Web Designer</h3>
                  <p className="text-muted-foreground">Alif Media Solutions</p>
                  <p>
                    During these years, I worked as a senior Web Designer at leading Web & Media company in kerala, India.
                    This was a great milestone in my career journey.
                  </p>
                </div>

                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2014 - 2015</div>
                  <h3 className="text-lg font-semibold">Web & Graphic Designer</h3>
                  <p className="text-muted-foreground">Freelance</p>
                  <p>
                    My journey began over a decade ago. During my higher secondary studies, I embarked on the web world by creating a WAP site.
                    In those early days, I managed to gather a community with hundreds of users, marking the beginning of my exploration
                    into the vast realm of the internet.
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="education" className="mt-6 space-y-8">
                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2021 - 2024</div>
                  <h3 className="text-lg font-semibold">M.A English</h3>
                  <p className="text-muted-foreground">Indira Gandhi National Open University</p>
                  <p>
                    Honed My Masters Degree: Master of Arts in English Language & Literature
                    (Indira Gandhi National Open University, 2021-2024)
                  </p>
                </div>

                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2018 - 2020</div>
                  <h3 className="text-lg font-semibold">Degree in Islamic Studies</h3>
                  <p className="text-muted-foreground">Jamia Nooriyya Arabiyya, Kerala</p>
                  <p>
                    Enhanced My Understanding of Islamic Law & Ethics and Graduated from the prestigious
                    Islamic University Jamia Nooriyya Arabiyya, Kerala, India.
                  </p>
                </div>

                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2016 - 2019</div>
                  <h3 className="text-lg font-semibold">B.A English</h3>
                  <p className="text-muted-foreground">Indira Gandhi National Open University</p>
                  <p>
                    Honed My Bachelors Degree: Bachelor of Arts in English Language & Literature
                    (Indira Gandhi National Open University, 2016-2019)
                  </p>
                </div>

                <div className="space-y-2 border-l-2 border-primary/20 pl-4">
                  <div className="bg-primary text-primary-foreground inline-block text-xs px-2 py-1 rounded">2010 - 2013</div>
                  <h3 className="text-lg font-semibold">SSLC - Higher Secondary (Science)</h3>
                  <p className="text-muted-foreground">GHSS Kavanur</p>
                  <p>
                    Completed my Highschool & Higher Secondary studies at Government Higher Secondary School Kavanur
                    based in Malappuram, Kerala, India
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="skills" className="mt-6 space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">Graphic Design</p>
                    <p className="text-muted-foreground">95%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '95%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">Web Design</p>
                    <p className="text-muted-foreground">95%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '95%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">Digital Marketing</p>
                    <p className="text-muted-foreground">85%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '85%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">WordPress | Elementor | WPBakery</p>
                    <p className="text-muted-foreground">90%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">Social Media Management</p>
                    <p className="text-muted-foreground">90%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">Photography</p>
                    <p className="text-muted-foreground">90%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="font-medium">Videography</p>
                    <p className="text-muted-foreground">90%</p>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: '90%' }}></div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="awards" className="mt-6 space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="border p-6 rounded-lg">
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground mb-1">2022</p>
                      <h3 className="text-lg font-semibold">05x Developer Award</h3>
                      <p className="text-muted-foreground">Runners Up</p>
                    </div>
                  </div>

                  <div className="border p-6 rounded-lg">
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground mb-1">2021</p>
                      <h3 className="text-lg font-semibold">03x Developer Award</h3>
                      <p className="text-muted-foreground">Winner</p>
                    </div>
                  </div>

                  <div className="border p-6 rounded-lg">
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground mb-1">2019</p>
                      <h3 className="text-lg font-semibold">02x Developer Award</h3>
                      <p className="text-muted-foreground">Winner</p>
                    </div>
                  </div>

                  <div className="border p-6 rounded-lg">
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground mb-1">2018</p>
                      <h3 className="text-lg font-semibold">01x Developer Award</h3>
                      <p className="text-muted-foreground">Nominee</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
